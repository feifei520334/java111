public class task10 {
    public static void main(String[] args) {
        String message = "Welcome to Java";
        System.out.println("The message in lowercase is: " + message.toLowerCase());
        System.out.println("The message in UPPERCASE is: " + message.toUpperCase());
    }
}
