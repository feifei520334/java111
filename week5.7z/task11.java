public class task11 {
    public static void main(String[] args) {
        // Three strings are concatenated
        String message = "Welcome" + "to" + "Java";
        // String Chapter is concatenated with number 2
        String s = "Chapter" + 2; // s becomes Chapter2
        // String Supplement is concatenated with character B
        String s1 = "Supplement" + 'B'; // s1 becomes SupplementB
    }
}
