public class task2 {

    public static void main(String[] args) {
        System.out.println("The value of exp(3.5): " + Math.exp(3.5));
        System.out.println("The value of log(3.5): " + Math.log(3.5));
        System.out.println("The value of log10(3.5): " + Math.log10(3.5));
        System.out.println("The value of power(3,2): " + Math.pow(3, 2));
        System.out.println("The value of sqrt(4): " + Math.sqrt(4));
        System.out.println("The value of sqrt(10.5): " + Math.sqrt(10.5));
    }
}