public class task8 {
    public static void main(String[] args) {
        String message = "Welcome to Java";
        System.out.println("The length of " + message + " is " + message.length());
    }
}
